/*******************************************************************************
 * This software is provided AS IS and without warranty of any kind. 
 * Your right to use this software is subject to separate terms and conditions entered between you and NXP.
 * If you have not entered into such terms, you have no license rights to use the code.
 * Copyright 2012-2016 Freescale Semiconductor, Inc.
 * Copyright 2017~2019 NXP.
 * All rights reserved.
 *******************************************************************************/


#include "defines.h"
#include "cpu.h"

#include "appCfg.h"
#include "Wct_Lib.h"

#include "freemaster.h"
#include "freemaster_cfg.h"

#include "systemTimers.h"
#include "systemDebug.h"

#include "adc.h"
#include "timer.h"
#include "dma.h"
#include "qsci.h"
#include "FlexCAN.h"


#include "hal.h"

#include "event.h"
#include "NVM.h"
#include "wct_LibParams.h"
#include "systemLINHandler.h"
#include "systemTask.h"
#include "gpio.h"

#include "qsci.h"

#define CHECK_PARITY 1



volatile uint8 gDBG_byIntNum;
volatile uint8 gDBG_byIntPri;

static uint8 receive_BUFF[32];
static uint8 LIN_CMD_BUFF[16];
static uint8 receive_number;
static uint8 transfer_BUFF[9];
static uint8 transfer_number=0;
static uint8 bIsLINCMDIN = FALSE;
//static uint8 LinCmdNum = 0;
static uint8 LinRecvCmdNum = 0;

static uint8 rawPid;
static uint8 WpcSta;
uint8 SWVersion = 0x00;		// v0.0.6
							// main           00
							// secondary      000
							// modify         001

// add by jiangxl 20191026 for TEME software version display
//uint8 TEMEVersion = 0x01;	// v0.0.7.1
uint8 TEMEVersion = 0x02;	// v0.0.6.3	// modify by jiangxl for ate

//0.0.1  �޸�PEPS���ʱ��
//0.0.2  �޸ı궨�ļ�


static uint8 bIsLINManufCMDIN;
static uint8 LinManufCmdNum = 0;

uint16 check_sum;
uint8 bTestCmd;
static uint16 LinRdCmdTimerTick;

static uint8 RECEIVE_SCI_CMD_BUFF[11];
uint8 RECEIVE_SCI_CMD_sucess=0;

extern uint8 CMD_DELAY_ms;

void SetLinRdCmdTick()
{
	LinRdCmdTimerTick = ST_GetTimerTick();
}


void LinRdCmdTimeoutHandler(uint16 time)
{
	if(ST_GetElapasedTime(LinRdCmdTimerTick)>time)
	{
		QSCI1_Init(19200ul);
	    LINCommand_Init();
	    SciIntCmdInit();
	    SetLinRdCmdTick();
	}
}

uint8 lin_process_parity(uint8 pid, uint8 type)
 {
 	uint8 parity;
 	uint8 ret;
 	uint8 bit0, bit1, bit2, bit3, bit4, bit5;
 	bit0 = pid&0x01;
 	bit1 = (pid>>1)&0x01;
 	bit2 = (pid>>2)&0x01;
 	bit3 = (pid>>3)&0x01;
 	bit4 = (pid>>4)&0x01;
 	bit5 = (pid>>5)&0x01;

     parity = ((bit0^bit1^bit2^bit4) << 6)|
               ((~(bit1^bit3^bit4^bit5)) << 7);
     if (CHECK_PARITY == type)
     {
         if ((pid&0xC0) != parity)
         {
             ret = 0xFF;
         }
         else
         {
             ret = (uint8)(pid&0x3F);
         }
     }
     else
     {
         ret = (uint8)(pid|parity);
     }

     return (ret);
 }
 
uint8 lin_checksum(uint8 *buffer, uint8 raw_pid)
{
	uint8 i;
	//uint8 check_sum;

    /* 1. PID correspond to Master request and Slave response, their checksum cal is classic
    the non-diagnostic frame is calculated in Enhanced */
    //if ((0x3C != raw_pid) && (0x7D != raw_pid))
    //{
    //    check_sum = raw_pid;
    //}
    //else
    //{
    //    check_sum = 0;
    //}
    if((raw_pid==0x3C) || (raw_pid==0x7D) || (raw_pid==0xBF))  // 60 61 62 63 use classic checksum
    {
        check_sum = 0;
    }
    else		// others use enhanced checksum
    {
        check_sum = raw_pid;
    }
	

    for (i = 0; i < 8; i++)
    {
        
        check_sum += *(buffer);
        buffer++;
        /* 2. to deal with the carry */
        if (check_sum > 0xFF)
        {
            check_sum -= 0xFF;
        }
    }

    /* 3. to reverse */
    return (uint8)(~check_sum);
}

void SetLINCommandOut(uint8 wpcstatus)
{
  if(wpcstatus<0x0f)
  {
	WpcSta = wpcstatus;
  }
  else
  {
	  WpcSta = 0xf;  
  }
}

uint8 GetATETestCmd()
{
	uint8 AteTestCmd;
	AteTestCmd = LIN_CMD_NONE;
	
	if((gWCT_Params.LinManufCmd>>16)==0x55AA)
	{
		AteTestCmd = LIN_CMD_ATE;
	}
	else if((gWCT_Params.LinManufCmd>>16) == 0x5505)
	{
		AteTestCmd = LIN_CMD_QFACTOR_REINIT;
	}
	
	return AteTestCmd;
}

uint8 GetATETestPartCmd()
{
	uint8 AteTestPartCmd;
	AteTestPartCmd = ATE_CMD_FULL;
	if((gWCT_Params.LinManufCmd>>16)==0x55AA)
	{
		if(((gWCT_Params.LinManufCmd>>8)&0xFF) == 0x01)
		{
			AteTestPartCmd = ATE_CMD_PART;
		}
	}
	return AteTestPartCmd;
	
}

void ResetATETestCmd()
{
	gWCT_Params.LinManufCmd = 0x0;
}

void SciIntCmdInit()
{
	receive_number = 0;
	transfer_number=0;
	bIsLINCMDIN = FALSE;
	bIsLINManufCMDIN = FALSE;
//	LinCmdNum = 0;
	LinManufCmdNum = 0;
	transfer_number = 10; //0;
	LIN_CMD_BUFF[0] = 0x3;
	gWCT_Params.LinCmd = 0x3;
	rawPid = 0x85;
	WpcSta = 0x0;
}

#pragma interrupt alignsp saveall
void MWCT10xx_ISR_UNDEFINED(void)
{
    //Save the ISR number and priority to global variables, for debug purpose
    gDBG_byIntNum = (INTC_CTRL >> 6) & 0x7F;
    gDBG_byIntPri = (INTC_CTRL >> 13) & 0x03;
    while(1) {}
}
#pragma interrupt off

#pragma interrupt alignsp saveall
void MWCT10xx_ISR_TMRA_0(void)
{
    //DDM ISR
	static uint8 fsk_cnt;
	
	TMR_ISRAck(TMR_DDM_FRQ_INDEX);  //clear timer interrupt flag
	
	//HAL_SetTP(0, HAL_TP_TYPE_SET);
	
	if (FSK_IsBusy(0))
	{
	    //FSK is sending data, ignore DDM
		fsk_cnt++;
		if (fsk_cnt >= 256/(RECORD_BUF_LEN/2/2))
		{
		    //FSK ISR should be called every 256 PWM cycles.
			fsk_cnt = 0;
			FSK_ISR(0);
		}
	}
	else
	{
		WCT_CommAnalyse(0); 
		fsk_cnt = 256/(RECORD_BUF_LEN/2/2) - 1;  //Make sure FSK_ISR could be run at next interrupt
	}
	
	//HAL_SetTP(0, HAL_TP_TYPE_CLR);
}
#pragma interrupt off

#pragma interrupt saveall
void MWCT10xx_ISR_DMA0(void)
{
	DMA_ISRAck(DMA_ADC_INDEX);	
	DBG_Assert(1, 0, 0);  //we should not reach here, must got error
}
#pragma interrupt off

#pragma interrupt saveall
void MWCT10xx_ISR_TMRA_2(void)
{
    //1ms tick ISR
	TMR_ISRAck(TMR_TICK_INDEX);
	ST_TimerUpdate();
#if DIGITAL_DCDC
	HAL_MiscADCRead();  // for D_DCDC, ADCA starts sample every D_DCDC PID control routine
#else
	ADC_StartConversion(ADC_MISC_INDEX);
#endif
}
#pragma interrupt off


#pragma interrupt alignsp saveall
void MWCT10xx_ISR_TX_REG(void)
{
#if FREEMASTER_SUPPORTED && FMSTR_USE_JTAG
	FMSTR_Isr();
#else
	DBG_Assert(1, 0, 0);
#endif
}
#pragma interrupt off

#pragma interrupt alignsp saveall
void MWCT10xx_ISR_RX_REG(void)
{
#if FREEMASTER_SUPPORTED && FMSTR_USE_JTAG
	FMSTR_Isr();
#else
	DBG_Assert(1, 0, 0);
#endif
}
#pragma interrupt off

#pragma interrupt alignsp saveall
void MWCT10xx_ISR_QSCI0_TDRE(void)
{
#if FREEMASTER_SUPPORTED && FMSTR_USE_SCI && (FMSTR_SCI_BASE == 0xE080)
	FMSTR_Isr();
#endif
	
#if DEBUG_CONSOLE_SUPPORTED && (QSCI_CONSOLE_INDEX == 0)
	QSCI_ISRAck(QSCI_CONSOLE_INDEX);
	HAL_PrintCharISRAck();
#endif
}
#pragma interrupt off

#pragma interrupt alignsp saveall
void MWCT10xx_ISR_QSCI0_RCV(void)
{
#if FREEMASTER_SUPPORTED && FMSTR_USE_SCI && (FMSTR_SCI_BASE == 0xE080)
	FMSTR_Isr();
#endif
}
#pragma interrupt off
/**********************************************/


/*************************************************************/
/*                       �����У��λ                        */
/*************************************************************/
//check_sum = raw_pid;
/*
for (i = 0; i < 8; i++)
{
    
    check_sum += *(buffer);
    buffer++;
    // 2. to deal with the carry //
    if (check_sum > 0xFF)
    {
        check_sum -= 0xFF;
    }
}
*/
/* 3. to reverse */
//return (uint8)(~check_sum);



void RECEIVE_SCI_CMD_Check(void)
     {
	  unsigned char i;
	  check_sum=0;
	  if(RECEIVE_SCI_CMD_sucess == 0xa5)
	  {
	     for (i = 0; i < 9; i++)
	       {
	      
	          check_sum += RECEIVE_SCI_CMD_BUFF[i];
	          /* 2. to deal with the carry */
	          if (check_sum > 0xFF)
	             {
	              check_sum -= 0xFF;
	             }
	        }    
		    
		 if((uint8)(~check_sum) == RECEIVE_SCI_CMD_BUFF[9])  
		   {
			  gWCT_Params.LinCmd = RECEIVE_SCI_CMD_BUFF[1];    //���յ���ȷ������
		   }
		 //���յ�������Ϊ����״̬��
		 
	   }
	  }


LIN_BYTE0 MSG0;

/***************?a��?��??������?����?SCI1��??����??D??****************/
#pragma interrupt alignsp saveall
void MWCT10xx_ISR_QSCI1_RCV(void)
{	
	uint8 RECEIVE_SCI=0;
	uint8 current_id;
	uint8 emptyFieldnum, preambleFieldnum;

	//add by jiangxl 20190802 for LIN Comm debug
	//GPIOC2_TOGGLE();
	
	QSCI_ISRAck(1);
	RECEIVE_SCI = (QSCI1_DATA&0xff);//

	
	receive_BUFF[receive_number]=RECEIVE_SCI;
	if(bIsLINCMDIN)
	{
		//gWCT_Params.LinCmd = RECEIVE_SCI; //���յ����������ݰ�����ʶ��Ϊ�����ź�
		LinManufCmdNum++;
		RECEIVE_SCI_CMD_BUFF[LinManufCmdNum]=RECEIVE_SCI;
		
		if(LinManufCmdNum>=10&& CMD_DELAY_ms<=8)                   //�������ݰ���7ms�ڽ��յ�Ϊһ�������İ�
		  {
			RECEIVE_SCI_CMD_sucess=0xa5;
			bIsLINCMDIN = FALSE;
			LinManufCmdNum=0;
		  }
	}
	else if(bIsLINManufCMDIN)
	{
		//if(LinManufCmdNum==1)
		if(LinManufCmdNum==3)
		{
			gWCT_Params.LinManufCmd |= RECEIVE_SCI;
			LinManufCmdNum = 0;
			bIsLINManufCMDIN = FALSE;
			if((gWCT_Params.LinManufCmd>>16)==0x55AA)
			{
				bTestCmd = LIN_CMD_ATE;
			}
			else if((gWCT_Params.LinManufCmd>>16)==0x5501)
			{
				bTestCmd = LIN_CMD_VIN_RD;
			}
			else if((gWCT_Params.LinManufCmd>>16)==0x5505)
			{
				bTestCmd = LIN_CMD_QFACTOR_REINIT;
				SetReCalib();
				//CMD_Notify(WCT_CMD_RE_CALIBRATION);
				//NVM_ReCalibration();
			}
		///////////////////////////////////////////
		//	LinManufCmdNum++;
	//		LinManufCmd[LinManufCmdNum]=RECEIVE_SCI;
		////////////////////////////////////////////	
		}
		else
		{
			
			
			gWCT_Params.LinManufCmd |= RECEIVE_SCI;
			gWCT_Params.LinManufCmd = gWCT_Params.LinManufCmd<<8;
			LinManufCmdNum++;
			/////////////////////////////////////////////////////////
	//		LinManufCmd[LinManufCmdNum]=RECEIVE_SCI;
		//	if(LinManufCmdNum==9)
		//	{
			
		//	}
			/////////////////////////////////////////////////////////
		}
		
	}
	
	if(receive_number>1)                                      // current number=2,3,4...
	{
		emptyFieldnum = receive_number - 2;
		preambleFieldnum = receive_number - 1;
	}
	else if(receive_number==1)                                 // current number=1
	{
		emptyFieldnum = sizeof(receive_BUFF)-1;
		preambleFieldnum = 0;
	}
	else														// current number=0
	{
		emptyFieldnum = sizeof(receive_BUFF)-2;
		preambleFieldnum = sizeof(receive_BUFF)-1;
	}
		
	//if((receive_BUFF[receive_number-1]==0x55) && (receive_BUFF[receive_number-2]==0x00))
	if((receive_BUFF[preambleFieldnum]==0x55) && (receive_BUFF[emptyFieldnum]==0x00))
		{
			current_id = lin_process_parity(RECEIVE_SCI, 1);
			//if((current_id==0x1F) || (current_id==0x05))
			if(current_id==0x28) //BX11��ʶ��ID��
			{
				rawPid = RECEIVE_SCI;
				
				/*if(current_id==0x1F)
				{
					SetLinRdCmdTick();		// if received 0x1F, Reset Timer
					transfer_BUFF[0] = WpcSta;
				}
				else
				{
					transfer_BUFF[0] = SWVersion;
				}
				*/
				SetLinRdCmdTick();		// if received 0x1F, Reset Timer
				
				MSG0.byte=0;
				MSG0.bits.L_WCM_ModuleStateRse=WpcSta;  //WCM_ModuleStateRse_F
				MSG0.bits.WCM_01_LIN_Response_Error=0;	 //WCM_01_LIN_Response_Error_F
				MSG0.bits.L_WCM_ErrorRes=0;	  //WCM_01_LIN_Response_Error_F
				transfer_BUFF[0] =MSG0.byte;
				transfer_BUFF[1] = 0xFF;
				transfer_BUFF[2] = 0xFF;
				transfer_BUFF[3] = 0xFF;
				transfer_BUFF[4] = 0xFF;
				transfer_BUFF[5] = 0xFF;
				transfer_BUFF[6] = 0xFF;
				transfer_BUFF[7] = 0xFF;
				transfer_BUFF[8] = lin_checksum(transfer_BUFF,rawPid);

				transfer_number=0;
				QSCI1_CTRL1 |=BIT7; //�������ж�
				//QSCI1_CTRL1 &=~QSCI1_CTRL1_RFIE;//�ؽ����ж�
				
				receive_number=0;
				bIsLINCMDIN = FALSE;
				bIsLINManufCMDIN = FALSE; 
				LinRecvCmdNum = 0;

			}
			else if(current_id==0x1F) //��ʼ���տ����ź�
			{
				bIsLINCMDIN = TRUE;
				bIsLINManufCMDIN = FALSE; 
				LinManufCmdNum = 0;
				LinRecvCmdNum = 0;
				RECEIVE_SCI_CMD_BUFF[0]=RECEIVE_SCI; //�����ź�
				RECEIVE_SCI_CMD_BUFF[9]=0xa5;
				//ʱ����
				CMD_DELAY_ms = 0;

			}
			// v0.0.3 add Lin command for manufacture
			else if(current_id==62)
			{
				bIsLINManufCMDIN = TRUE;   //�ڲ���ϵĿ�������
				bIsLINCMDIN = FALSE;
				LinManufCmdNum = 0;
				LinRecvCmdNum = 0;

			}
			else if(current_id==63)
			{
				rawPid = RECEIVE_SCI;
				if(bTestCmd==LIN_CMD_ATE)
				{
					transfer_BUFF[0] = 0x00;
					switch(LinRecvCmdNum)
					{
					case 0:
						transfer_BUFF[1] = 0xA1;
						transfer_BUFF[2] = (GetAteParams0()>>8) & 0xFF;
						transfer_BUFF[3] = GetAteParams0() & 0xFF;
						transfer_BUFF[4] = (GetAteParams1()>>8) & 0xFF;
						transfer_BUFF[5] = GetAteParams1() & 0xFF;
						transfer_BUFF[6] = (GetAteParams2()>>8) & 0xFF;
						transfer_BUFF[7] = GetAteParams2() & 0xFF;
						break;
					case 1:
						transfer_BUFF[1] = 0xA2;
						transfer_BUFF[2] = (GetAteParams3()>>8) & 0xFF;
						transfer_BUFF[3] = GetAteParams3() & 0xFF;
						transfer_BUFF[4] = 0x00;
						transfer_BUFF[5] = 0x00;
						transfer_BUFF[6] = SWVersion;//0x00;
						transfer_BUFF[7] = TEMEVersion;//0x00;
						break;
					case 2:
						transfer_BUFF[1] = 0xA3;
						transfer_BUFF[2] = (GetAteParams4()>>8) & 0xFF;
						transfer_BUFF[3] = GetAteParams4() & 0xFF;
						transfer_BUFF[4] = (GetAteParams5()>>8) & 0xFF;
						transfer_BUFF[5] = GetAteParams5() & 0xFF;
						transfer_BUFF[6] = (GetAteParams6()>>8) & 0xFF;
						transfer_BUFF[7] = GetAteParams6() & 0xFF;
						break;
					case 3:
						transfer_BUFF[1] = 0xA4;
						transfer_BUFF[2] = (GetAteParams7()>>8) & 0xFF;
						transfer_BUFF[3] = GetAteParams7() & 0xFF;
						transfer_BUFF[4] = (GetAteParams8()>>8) & 0xFF;
						transfer_BUFF[5] = GetAteParams8() & 0xFF;
						transfer_BUFF[6] = (GetAteParams9()>>8) & 0xFF;
						transfer_BUFF[7] = GetAteParams9() & 0xFF;
						break;
					case 4:
						transfer_BUFF[1] = 0xA5;
						transfer_BUFF[2] = (GetAteParams10()>>8) & 0xFF;
						transfer_BUFF[3] = GetAteParams10() & 0xFF;
						transfer_BUFF[4] = (GetAteParams11()>>8) & 0xFF;
						transfer_BUFF[5] = GetAteParams11() & 0xFF;
						transfer_BUFF[6] = (GetAteParams12()>>8) & 0xFF;
						transfer_BUFF[7] = GetAteParams12() & 0xFF;
						break;
					default:
						break;
					}
					
				}
				else if(bTestCmd==LIN_CMD_VIN_RD)
				{

					switch(LinRecvCmdNum)					
					{					
					case 0:
						transfer_BUFF[0] = 0x01;
						transfer_BUFF[1] = 0xAA;
						transfer_BUFF[2] = 'T';       //ʹ��TEME�ڲ������ TM0101-020023
						transfer_BUFF[3] = 'M';
						transfer_BUFF[4] = '0';
						transfer_BUFF[5] = '1';
						transfer_BUFF[6] = '0';
						transfer_BUFF[7] = '1';
						break;
					case 1:
						transfer_BUFF[0] = 0x02;
						transfer_BUFF[1] = 0xAA;
						transfer_BUFF[2] = '0';
						transfer_BUFF[3] = '2';
						transfer_BUFF[4] = '0';
						transfer_BUFF[5] = '0';
						transfer_BUFF[6] = '2';
						transfer_BUFF[7] = '3';
						break;
					default:
						break;
					}
				}
				else if(bTestCmd==LIN_CMD_QFACTOR_REINIT)
				{
					transfer_BUFF[0] = 0x01;
					transfer_BUFF[1] = 0x01;
					transfer_BUFF[2] = 0x01;
					transfer_BUFF[3] = 0x01;
					transfer_BUFF[4] = 0x01;
					transfer_BUFF[5] = 0x01;
					transfer_BUFF[6] = 0x01;
					transfer_BUFF[7] = 0x01;
				}
				
				transfer_BUFF[8] = lin_checksum(transfer_BUFF,rawPid);

				transfer_number=0;
				QSCI1_CTRL1 |=BIT7;
				receive_number=0;
				bIsLINCMDIN = FALSE;
				bIsLINManufCMDIN = FALSE;
				
				LinRecvCmdNum++;
			}
			
			else
			{
				//receive_number = 0;
				bIsLINCMDIN = FALSE;
				bIsLINManufCMDIN = FALSE;
				//LinRecvCmdNum = 0;
//				LinCmdNum = 0;
			}
			
		}
	
	receive_number++;
	if(receive_number>=sizeof(receive_BUFF))
	{
		receive_number = 0;
	}
	//QSCI1_PutChar(RECEIVE_SCI);

}
#pragma interrupt off
#pragma interrupt alignsp saveall
void MWCT10xx_ISR_QSCI1_RERR(void)
{	   
	QSCI_ISRAck(1);

}
#pragma interrupt off

#pragma interrupt alignsp saveall
void MWCT10xx_ISR_QSCI1_TIDLE(void)
{	 
	QSCI_ISRAck(1);

}
#pragma interrupt off

#pragma interrupt alignsp saveall
void MWCT10xx_ISR_QSCI1_TDRE(void)
{	
	QSCI_ISRAck(1);
	QSCI1_DATA=transfer_BUFF[transfer_number];
	transfer_number++;
	if(transfer_number>8)                      //���������ݹ��ж�
	{
		QSCI1_CTRL1 &=~BIT7; //�ط����ж�
		
		//QSCI1_CTRL1 |=QSCI1_CTRL1_RFIE;; //�������ж�
		
		
	}
}
#pragma interrupt off

/******************************/
#pragma interrupt alignsp saveall
void MWCT10xx_ISR_PIT1_ROLLOVER(void)
{
#if LOW_POWER_MODE_ENABLE
    TMR_ISRAck(TMR_LOW_POWER_INDEX);
    TMR_Enable(TMR_LOW_POWER_INDEX, 0);
#endif
}
#pragma interrupt off

#if DIGITAL_DCDC
#pragma interrupt saveall
void MWCT10xx_ISR_TMRA_1(void)
{	
	TMR_ISRAck(TMR_D_DCDC_INDEX);
	HAL_D_DCDC_Adjust(0);
	HAL_D_DCDC_ADCHandler(0);
}
#pragma interrupt off

#else

#pragma interrupt alignsp saveall
void MWCT10xx_ISR_QSCI1_TDRE(void)
{
#if FREEMASTER_SUPPORTED && FMSTR_USE_SCI && (FMSTR_SCI_BASE == 0xE090)
	FMSTR_Isr();
#endif
	
#if DEBUG_CONSOLE_SUPPORTED && (QSCI_CONSOLE_INDEX == 1)
	QSCI_ISRAck(QSCI_CONSOLE_INDEX);
	HAL_PrintCharISRAck();
#endif
}
#pragma interrupt off

#pragma interrupt alignsp saveall
void MWCT10xx_ISR_QSCI1_RCV(void)
{
#if FREEMASTER_SUPPORTED && FMSTR_USE_SCI && (FMSTR_SCI_BASE == 0xE090)
	FMSTR_Isr();
#endif
}
#pragma interrupt off

#pragma interrupt alignsp saveall
void MWCT10xx_ISR_ADC_CC0(void)
{
    ADC_ISRAck(ADC_MISC_INDEX);
    HAL_MiscADCISRAck(0);        //For not D_DCDC, ADCA starts to sample every 1ms
}
#pragma interrupt off

#endif

#if CAN_SUPPORTED
#pragma interrupt alignsp saveall
void MWCT10xx_ISR_CAN_MB(void)
{
	FlexCAN_MB_ISRAck();
}
#pragma interrupt off

#pragma interrupt alignsp saveall
void MWCT10xx_ISR_CAN_BUSOFF(void)
{
	FlexCAN_BusOff_ISRAck();
}
#pragma interrupt off

#pragma interrupt alignsp saveall
void MWCT10xx_ISR_CAN_ERROR(void)
{
	FlexCAN_Error_ISRAck();
}
#pragma interrupt off

#pragma interrupt alignsp saveall
void MWCT10xx_ISR_CAN_TX_WARN(void)
{
	FlexCAN_TxWarning_ISRAck();
}
#pragma interrupt off

#pragma interrupt alignsp saveall
void MWCT10xx_ISR_CAN_RX_WARN(void)
{
	FlexCAN_RxWarning_ISRAck();
}
#pragma interrupt off

#pragma interrupt alignsp saveall
void MWCT10xx_ISR_CAN_WAKEUP(void)
{
	FlexCAN_Wakeup_ISRAck();
}
#pragma interrupt off
#endif
