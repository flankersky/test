/*******************************************************************************
 * This software is provided AS IS and without warranty of any kind. 
 * Your right to use this software is subject to separate terms and conditions entered between you and NXP.
 * If you have not entered into such terms, you have no license rights to use the code.
 * Copyright 2012-2016 Freescale Semiconductor, Inc.
 * Copyright 2017~2019 NXP.
 * All rights reserved.
*******************************************************************************/
#ifndef __EVENT_H__
#define __EVENT_H__


typedef enum
{
	LIN_CMD_ATE = 0,
	LIN_CMD_VIN_RD = 1,
	LIN_CMD_QFACTOR_REINIT = 2,
	LIN_CMD_NONE = 3
} LIN_CMD_NUM;

typedef enum
{
	ATE_CMD_PART = 1,
	ATE_CMD_FULL = 2,
	ATE_CMD_NONE = 3
} ATE_CMD_NUM;


typedef union
{
   uint8 byte;

    struct
    {
	   uint8 L_WCM_ModuleStateRse                   :4;
	   uint8 WCM_01_LIN_Response_Error              :1;   
	   uint8 L_WCM_ErrorRes                         :3;	   
    }bits;
}LIN_BYTE0;



void MWCT10xx_ISR_UNDEFINED(void);
void MWCT10xx_ISR_TMRA_0(void);
void MWCT10xx_ISR_DMA0(void);
void MWCT10xx_ISR_TMRA_2(void);
void MWCT10xx_ISR_TX_REG(void);
void MWCT10xx_ISR_RX_REG(void);
void MWCT10xx_ISR_QSCI0_TDRE(void);
void MWCT10xx_ISR_QSCI0_RCV(void);
/***********?������?����?SCI1��?��y???D??o����y����?�¡�????��?a??��?��?************/
void MWCT10xx_ISR_QSCI1_RCV(void);
void MWCT10xx_ISR_QSCI1_RERR(void);
void MWCT10xx_ISR_QSCI1_TIDLE(void);
void MWCT10xx_ISR_QSCI1_TDRE(void);

void SetLINCommandOut(uint8 wpcstatus);
uint8 GetLINCommandIn();
void SciIntCmdInit();

void SetLinRdCmdTick(void);
void LinRdCmdTimeoutHandler(uint16 time);

uint8 lin_process_parity(uint8 pid, uint8 type);
uint8 lin_checksum(uint8 *buffer, uint8 raw_pid);
void RECEIVE_SCI_CMD_Check(void);

uint8 GetATETestCmd(void);
void ResetATETestCmd(void);
uint8 GetATETestPartCmd(void);

/*********************************/
void MWCT10xx_ISR_PIT1_ROLLOVER(void);
#if DIGITAL_DCDC
void MWCT10xx_ISR_TMRA_1(void);
#else
void MWCT10xx_ISR_ADC_CC0(void);
void MWCT10xx_ISR_QSCI1_TDRE(void);
void MWCT10xx_ISR_QSCI1_RCV(void);
#endif

#if CAN_SUPPORTED
void MWCT10xx_ISR_CAN_MB(void);
void MWCT10xx_ISR_CAN_BUSOFF(void);
void MWCT10xx_ISR_CAN_ERROR(void);
void MWCT10xx_ISR_CAN_TX_WARN(void);
void MWCT10xx_ISR_CAN_RX_WARN(void);
void MWCT10xx_ISR_CAN_WAKEUP(void);
#endif


#endif
