/* *************************
 * This software is provided AS IS and without warranty of any kind. 
 * Your right to use this software is subject to separate terms and conditions entered between you and NXP.
 * If you have not entered into such terms, you have no license rights to use the code.
 * Copyright 2018~2019 NXP.
 * All rights reserved.
**************************** */

#ifdef RW_SUPPORT
#include <string.h>
#include "RW_NDEF.h"
#include "RW_NDEF_T2T.h"

/* TODO: No support for tag larger than 1024 bytes (requiring SECTOR_SELECT command use) */

#define T2T_MAGIC_NUMBER	0xE1
#define T2T_NDEF_TLV		0x03

typedef enum
{
	Initial,
	Reading_CC,
	Reading_Data,
	Reading_NDEF,
	Writing_Data
} RW_NDEF_T2T_state_t;

typedef struct
{
	unsigned char BlkNb;
	unsigned short MessagePtr;
	unsigned short MessageSize;
	unsigned char *pMessage;
} RW_NDEF_T2T_Ndef_t;

static RW_NDEF_T2T_state_t eRW_NDEF_T2T_State = Initial;
static RW_NDEF_T2T_Ndef_t RW_NDEF_T2T_Ndef;

void RW_NDEF_T2T_Reset(void)
{
	eRW_NDEF_T2T_State = Initial;
	RW_NDEF_T2T_Ndef.pMessage = NdefBuffer;
}

void RW_NDEF_T2T_Read_Next(unsigned char *pRsp, unsigned short Rsp_size, unsigned char *pCmd, unsigned short *pCmd_size)
{
	/* By default no further command to be sent */
	*pCmd_size = 0;

	switch(eRW_NDEF_T2T_State)
	{
	case Initial:
		/* Read CC */
		pCmd[0] = 0x30;
		pCmd[1] = 0x03;
		*pCmd_size = 2;
		eRW_NDEF_T2T_State = Reading_CC;
		break;

	case Reading_CC:
		/* Is CC Read and Is Ndef ?*/
		if ((Rsp_size == 17) && (pRsp[Rsp_size-1] == 0x00) && (pRsp[0] == T2T_MAGIC_NUMBER))
		{
			/* Read First data */
			pCmd[0] = 0x30;
			pCmd[1] = 0x04;
			*pCmd_size = 2;

			eRW_NDEF_T2T_State = Reading_Data;
		}
		break;

	case Reading_Data:
		/* Is Read success ?*/
		if ((Rsp_size == 17) && (pRsp[Rsp_size-1] == 0x00))
		{
			unsigned char Tmp = 0;
			/* If not NDEF Type skip TLV */
			while (pRsp[Tmp] != T2T_NDEF_TLV)
			{
				Tmp += 2 + pRsp[Tmp+1];
				if (Tmp > Rsp_size) return;
			}

			if(pRsp[Tmp+1] == 0xFF)
			{
				RW_NDEF_T2T_Ndef.MessageSize = (pRsp[Tmp+2] << 8) + pRsp[Tmp+3];
				Tmp += 2;
			}
			else RW_NDEF_T2T_Ndef.MessageSize = pRsp[Tmp+1];

			/* If provisioned buffer is not large enough, notify the application and stop reading */
			if (RW_NDEF_T2T_Ndef.MessageSize > RW_MAX_NDEF_FILE_SIZE)
			{
				if(pRW_NDEF_PullCb != NULL) pRW_NDEF_PullCb(NULL, 0);
				break;
			}

			/* Is NDEF read already completed ? */
			if (RW_NDEF_T2T_Ndef.MessageSize <= ((Rsp_size-1) - Tmp - 2))
			{
				memcpy (RW_NDEF_T2T_Ndef.pMessage, &pRsp[Tmp+2], RW_NDEF_T2T_Ndef.MessageSize);

				/* Notify application of the NDEF reception */
				if(pRW_NDEF_PullCb != NULL) pRW_NDEF_PullCb(RW_NDEF_T2T_Ndef.pMessage, RW_NDEF_T2T_Ndef.MessageSize);
			}
			else
			{
				RW_NDEF_T2T_Ndef.MessagePtr = (Rsp_size-1) - Tmp - 2;
				memcpy (RW_NDEF_T2T_Ndef.pMessage, &pRsp[Tmp+2], RW_NDEF_T2T_Ndef.MessagePtr);
				RW_NDEF_T2T_Ndef.BlkNb = 8;

				/* Read NDEF content */
				pCmd[0] = 0x30;
				pCmd[1] = RW_NDEF_T2T_Ndef.BlkNb;
				*pCmd_size = 2;
				eRW_NDEF_T2T_State = Reading_NDEF;
			}
		}
		break;

		case Reading_NDEF:
		/* Is Read success ?*/
		if ((Rsp_size == 17) && (pRsp[Rsp_size-1] == 0x00))
		{
			/* Is NDEF read already completed ? */
			if ((RW_NDEF_T2T_Ndef.MessageSize - RW_NDEF_T2T_Ndef.MessagePtr) < 16)
			{
				memcpy (&RW_NDEF_T2T_Ndef.pMessage[RW_NDEF_T2T_Ndef.MessagePtr], pRsp, RW_NDEF_T2T_Ndef.MessageSize - RW_NDEF_T2T_Ndef.MessagePtr);

				/* Notify application of the NDEF reception */
				if(pRW_NDEF_PullCb != NULL) pRW_NDEF_PullCb(RW_NDEF_T2T_Ndef.pMessage, RW_NDEF_T2T_Ndef.MessageSize);
			}
			else
			{
				memcpy (&RW_NDEF_T2T_Ndef.pMessage[RW_NDEF_T2T_Ndef.MessagePtr], pRsp, 16);
				RW_NDEF_T2T_Ndef.MessagePtr += 16;
				RW_NDEF_T2T_Ndef.BlkNb += 4;

				/* Read NDEF content */
				pCmd[0] = 0x30;
				pCmd[1] = RW_NDEF_T2T_Ndef.BlkNb;
				*pCmd_size = 2;
			}
		}
		break;

	default:
		break;
	}
}

void RW_NDEF_T2T_Write_Next(unsigned char *pRsp, unsigned short Rsp_size, unsigned char *pCmd, unsigned short *pCmd_size)
{
	/* By default no further command to be sent */
	*pCmd_size = 0;

	switch(eRW_NDEF_T2T_State)
	{
	case Initial:
		/* Read CC */
		pCmd[0] = 0x30;
		pCmd[1] = 0x03;
		*pCmd_size = 2;
		eRW_NDEF_T2T_State = Reading_CC;
		break;

	case Reading_CC:
		/* Is CC Read, Is Ndef and is R/W ?*/
		if ((Rsp_size == 17) && (pRsp[Rsp_size-1] == 0x00) && (pRsp[0] == T2T_MAGIC_NUMBER) && (pRsp[3] == 0x00))
		{
			/* Is size enough ? */
			if (pRsp[2]*8 >= NdefMessage_size)
			{
				/* Write First data */
				pCmd[0] = 0xA2;
				pCmd[1] = 0x04;
				pCmd[2] = 0x03;
				if (NdefMessage_size > 0xFF)
				{
					pCmd[3] = 0xFF;
					pCmd[4] = (NdefMessage_size & 0xFF00) >> 8;
					pCmd[5] = NdefMessage_size & 0xFF;
					RW_NDEF_T2T_Ndef.MessagePtr = 0;
				}
				else
				{
					pCmd[3] = NdefMessage_size;
					memcpy(&pCmd[4], pNdefMessage, 2);
					RW_NDEF_T2T_Ndef.MessagePtr = 2;
				}
				RW_NDEF_T2T_Ndef.BlkNb = 5;
				*pCmd_size = 6;
				eRW_NDEF_T2T_State = Writing_Data;
			}
		}
		break;

	case Writing_Data:
		/* Is Write success ?*/
		if ((Rsp_size == 2) && (pRsp[Rsp_size-1] == 0x00))
		{
			/* Is NDEF write already completed ? */
			if (NdefMessage_size <= RW_NDEF_T2T_Ndef.MessagePtr)
			{
				/* Notify application of the NDEF reception */
				if(pRW_NDEF_PushCb != NULL) pRW_NDEF_PushCb(pNdefMessage, NdefMessage_size);
			}
			else
			{
				/* Write NDEF content */
				pCmd[0] = 0xA2;
				pCmd[1] = RW_NDEF_T2T_Ndef.BlkNb;
				memcpy(&pCmd[2], pNdefMessage+RW_NDEF_T2T_Ndef.MessagePtr, 4);
				*pCmd_size = 6;

				RW_NDEF_T2T_Ndef.MessagePtr+=4;
				RW_NDEF_T2T_Ndef.BlkNb++;
			}
		}
		break;

	default:
		break;
	}
}

#endif
