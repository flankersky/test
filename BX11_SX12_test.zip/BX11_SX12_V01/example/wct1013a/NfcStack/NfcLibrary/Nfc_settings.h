/* *************************
 * This software is provided AS IS and without warranty of any kind. 
 * Your right to use this software is subject to separate terms and conditions entered between you and NXP.
 * If you have not entered into such terms, you have no license rights to use the code.
 * Copyright 2018~2019 NXP.
 * All rights reserved.
**************************** */

#ifndef __NFC_SETTINGS_H__
#define __NFC_SETTINGS_H__

/***** NFC dedicated setting ****************************************/
//#include "cpu.h"
/* Following definitions specifies which settings will apply when NxpNci_ConfigureSettings()
 * API is called from the application
 */
#define NXP_CORE_CONF 		0
#define NXP_CORE_CONF_EXTN	0
#define NXP_CORE_STANDBY 	0
#define NXP_RF_CONF		 	0

/* NCI standard dedicated settings
 * Refer to NFC Forum NCI standard for more details
 */
#if NXP_CORE_CONF
uint8_t NxpNci_CORE_CONF[]={0x20, 0x02, 0x07, 0x01, 	/* CORE_SET_CONFIG_CMD */
	0x33, 0x04, 0x04, 0x03, 0x02, 0x01,				/* LA_NFCID1 */
};
#endif

/* NXP-NCI extension dedicated setting
 * Refer to NFC controller User Manual for more details
 */
#if NXP_CORE_CONF_EXTN
uint8_t NxpNci_CORE_CONF_EXTN[]={0x20, 0x02, 0x05, 0x01, 	/* CORE_SET_CONFIG_CMD */
	0xA0, 0x40, 0x01, 0x01,								/* READER_TAG_DETECTOR_CFG */
};
#endif

/* NXP-NCI standby enable setting
 * Refer to NFC controller User Manual for more details
 */
#if NXP_CORE_STANDBY
uint8_t NxpNci_CORE_STANDBY[]={0x2F, 0x00, 0x01, 0x01};	/* last byte indicates enable/disable */
#endif

/* NXP-NCI RF configuration
 * Refer to NFC controller Antenna Design and Tuning Guidelines document for more details
 */
#if NXP_RF_CONF
/* RF configuration related to 1st generation of NXP-NCI controller (e.g PN7120) */
uint8_t NxpNci_RF_CONF_1stGen[]={0};

/* RF configuration related to 1st generation of NXP-NCI controller (e.g PN7150)*/
/* Following configuration relates to performance optimization of OM5578/PN7150 NFC Controller demo kit */
uint8_t NxpNci_RF_CONF_2ndGen[]={0x20, 0x02, 0xB7, 0x14,
	0xA0, 0x0D, 0x06, 0x04, 0x35, 0x90, 0x01, 0xF4, 0x01,  	/* RF_CLIF_CFG_INITIATOR        CLIF_AGC_INPUT_REG */
	0xA0, 0x0D, 0x06, 0x06, 0x44, 0x01, 0x90, 0x03, 0x00,	/* RF_CLIF_CFG_TARGET           CLIF_ANA_RX_REG */
	0xA0, 0x0D, 0x06, 0x06, 0x30, 0xB0, 0x01, 0x10, 0x00,	/* RF_CLIF_CFG_TARGET           CLIF_SIGPRO_ADCBCM_THRESHOLD_REG */
	0xA0, 0x0D, 0x06, 0x06, 0x42, 0x02, 0x00, 0xFF, 0xFF,	/* RF_CLIF_CFG_TARGET           CLIF_ANA_TX_AMPLITUDE_REG */
	0xA0, 0x0D, 0x03, 0x06, 0x3F, 0x06,						/* RF_CLIF_CFG_TARGET           CLIF_TEST_CONTROL_REG */
	0xA0, 0x0D, 0x06, 0x20, 0x42, 0x88, 0x00, 0xFF, 0xFF,	/* RF_CLIF_CFG_TECHNO_I_TX15693 CLIF_ANA_TX_AMPLITUDE_REG */
	0xA0, 0x0D, 0x04, 0x22, 0x44, 0x23, 0x00,				/* RF_CLIF_CFG_TECHNO_I_RX15693 CLIF_ANA_RX_REG */
	0xA0, 0x0D, 0x06, 0x22, 0x2D, 0x50, 0x34, 0x0C, 0x00,	/* RF_CLIF_CFG_TECHNO_I_RX15693 CLIF_SIGPRO_RM_CONFIG1_REG */
	0xA0, 0x0D, 0x06, 0x32, 0x42, 0xF8, 0x00, 0xFF, 0xFF,	/* RF_CLIF_CFG_BR_106_I_TXA     CLIF_ANA_TX_AMPLITUDE_REG */
	0xA0, 0x0D, 0x06, 0x34, 0x2D, 0x24, 0x37, 0x0C, 0x00,	/* RF_CLIF_CFG_BR_106_I_RXA_P   CLIF_SIGPRO_RM_CONFIG1_REG */
	0xA0, 0x0D, 0x06, 0x34, 0x33, 0x86, 0x80, 0x00, 0x70,	/* RF_CLIF_CFG_BR_106_I_RXA_P   CLIF_AGC_CONFIG0_REG */
	0xA0, 0x0D, 0x04, 0x34, 0x44, 0x22, 0x00,				/* RF_CLIF_CFG_BR_106_I_RXA_P   CLIF_ANA_RX_REG */
	0xA0, 0x0D, 0x06, 0x42, 0x2D, 0x15, 0x45, 0x0D, 0x00,	/* RF_CLIF_CFG_BR_848_I_RXA     CLIF_SIGPRO_RM_CONFIG1_REG */
	0xA0, 0x0D, 0x04, 0x46, 0x44, 0x22, 0x00,				/* RF_CLIF_CFG_BR_106_I_RXB     CLIF_ANA_RX_REG */
	0xA0, 0x0D, 0x06, 0x46, 0x2D, 0x05, 0x59, 0x0E, 0x00,	/* RF_CLIF_CFG_BR_106_I_RXB     CLIF_SIGPRO_RM_CONFIG1_REG */
	0xA0, 0x0D, 0x06, 0x44, 0x42, 0x88, 0x00, 0xFF, 0xFF,	/* RF_CLIF_CFG_BR_106_I_TXB     CLIF_ANA_TX_AMPLITUDE_REG */
	0xA0, 0x0D, 0x06, 0x56, 0x2D, 0x05, 0x9F, 0x0C, 0x00,	/* RF_CLIF_CFG_BR_212_I_RXF_P   CLIF_SIGPRO_RM_CONFIG1_REG */
	0xA0, 0x0D, 0x06, 0x54, 0x42, 0x88, 0x00, 0xFF, 0xFF,	/* RF_CLIF_CFG_BR_212_I_TXF     CLIF_ANA_TX_AMPLITUDE_REG */
	0xA0, 0x0D, 0x06, 0x0A, 0x33, 0x80, 0x86, 0x00, 0x70,	/* RF_CLIF_CFG_I_ACTIVE         CLIF_AGC_CONFIG0_REG */
	0xA0, 0x1D, 0x11, 0x57, 0x33, 0x14, 0x17, 0x00, 0xAA, 0x85, 0x00, 0x80, 0x55, 0x2A, 0x04, 0x00, 0x63, 0x00, 0x00, 0x00
};
#endif

#endif
