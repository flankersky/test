/* *************************
 * This software is provided AS IS and without warranty of any kind. 
 * Your right to use this software is subject to separate terms and conditions entered between you and NXP.
 * If you have not entered into such terms, you have no license rights to use the code.
 * Copyright 2018~2019 NXP.
 * All rights reserved.
**************************** */

#ifndef __NFC_DRIVER_CONFIG_H__
#define __NFC_DRIVER_CONFIG_H__

#include "cpu.h"
#include "defines.h"
#include "systemTimers.h"

/***********************************************************************************************
 **	Global macros and definitions
 ***********************************************************************************************/
#define NXPNCI_I2C_ADDR		  					0x28U

#define HIGH              	  					1
#define LOW               	  					0

#define ERROR									0
#define SUCCESS									1

#define SET_VEN_HIGH							(GPIOA_DR |= (1<<2))
#define SET_VEN_LOW								(GPIOA_DR &= ~(1<<2))
#define GET_IRQ_VALUE							(GPIOB_DR & (1<<4))

#define SLEEP( ms )								ST_WaitMs( ms )

//For test
#define LED_RED_ON								(GPIOE_DR &= ~0x01)
#define LED_RED_OFF								(GPIOE_DR |= 0x01)
#define LED_RED_TOGGLE		    				(GPIOE_DR ^= 0x01)
/***********************************************************************************************
 **	Global variables
 ***********************************************************************************************/

/***********************************************************************************************
 **	Global function prototypes
 ***********************************************************************************************/

#endif // __NFC_DRIVER_CONFIG_H__

/***********************************************************************************************
 **                            End Of File
 ***********************************************************************************************/
