/*******************************************************************************
 * This software is provided AS IS and without warranty of any kind. 
 * Your right to use this software is subject to separate terms and conditions entered between you and NXP.
 * If you have not entered into such terms, you have no license rights to use the code.
 * Copyright 2012-2016 Freescale Semiconductor, Inc.
 * Copyright 2017~2019 NXP.
 * All rights reserved.
*******************************************************************************/

#ifndef __SYSTEMTASK_H__
#define __SYSTEMTASK_H__

typedef enum
{
    APP_SUCCESS         = 0,
    APP_NVM_ERROR       = 0x01,
    APP_OVER_TEMP_ERROR = 0x02,
    APP_OVER_VOL_ERROR  = 0x04,
    APP_UNDER_VOL_ERROR = 0x08,
    APP_ERROR_CLEAR     = 0x8000
} APP_ERROR_TYPE;

void App_SetErr(APP_ERROR_TYPE err);
APP_ERROR_TYPE App_GetErr(void);
void AppTask_Poll(void);

void SetReCalib(void);

#endif
