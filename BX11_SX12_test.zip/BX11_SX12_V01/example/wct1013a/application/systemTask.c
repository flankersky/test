/*******************************************************************************
 * This software is provided AS IS and without warranty of any kind. 
 * Your right to use this software is subject to separate terms and conditions entered between you and NXP.
 * If you have not entered into such terms, you have no license rights to use the code.
 * Copyright 2012-2016 Freescale Semiconductor, Inc.
 * Copyright 2017~2019 NXP.
 * All rights reserved.
*******************************************************************************/
//----------------------
// APPLICATION INCLUDES
//----------------------

#include "defines.h"

#include "appCfg.h"
#include "Wct_Lib.h"

#include "hal.h"
#include "gpio.h"
#include "systemTimers.h"
#include "systemDisplay.h"
#include "systemCommand.h"
#include "systemProtection.h"
#include "systemCallback.h"

#include "wct_debug.h"
#include "systemTask.h"

#include "systemLINHandler.h"
#include "event.h"
#include "NVM.h"

#define NUM_1MS_COUNTS_FOR_10MS         10U
#define NUM_10MS_COUNTS_FOR_100MS       10U
#define NUM_100MS_COUNTS_FOR_1SEC       10U
#define NUM_1SEC_COUNTS_FOR_1MIN        60U

static uint8 Test_count1s = 0;
static uint8 FirstReCalib = FALSE;
static uint8 bReQfInit = FALSE;

uint8 CMD_DELAY_ms=0;

typedef struct
{
	uint16 w1msCount;
	uint16 w10msCount;
	uint16 w100msCount;
	uint16 w1secCount;
	uint16 w1minCount;
} TIMER_DATA;

APP_ERROR_TYPE gApp_error = APP_SUCCESS;

static void AppTask_1msHandle(uint16 wNumTicks)
{
	uint16 wLowPowerModeTimeMs;
	wLowPowerModeTimeMs = WCT_Run(wNumTicks);	
	CMD_Handler();
	if(LOW_POWER_MODE_TIME_INFINITE == wLowPowerModeTimeMs)	
	{
		//WCT library OFF, don't enter low power mode
	}
	else
	{
		HAL_EnterLowPowerMode(wLowPowerModeTimeMs);
	}
	
	if(CMD_DELAY_ms <200)
	    CMD_DELAY_ms++;
	
	//chen liyun  20200328 //Ӳ��PEPS ���ܴ���
	PEPS_Handler();
}

static void AppTask_10msHandle(uint16 wNumTicks)
{
#if FREEMASTER_SUPPORTED
	WBG_DebugProcess();
#endif
	PROT_CheckBoardParams(wNumTicks);
	DISP_Handler(wNumTicks);
	
	//chen liyun  20200328
	RECEIVE_SCI_CMD_Check();         //ʶ����յ�Ϊ��ȷ���ݷ�
	
	// add LIN command handler procedure here
	// Jiangxl 2019-03-14
	LINCommandIn_Handler(wNumTicks);
	LINCommandOut_Handler(wNumTicks);
	

	
	
	if(GetATETestCmd()==LIN_CMD_ATE)
	{
		
		if(GetATETestPartCmd()==ATE_CMD_PART)
		{
			systemATEHandler(ATE_CMD_PART);
		}
		else
		{
			systemATEHandler(ATE_CMD_FULL);
		}
		ResetATETestCmd();
	}
	//else if(AteTestCmd()==LIN_CMD_QFACTOR_REINIT)
	//{
		
	//}
	// change timeout 5000 for ATE 20190806
	LinRdCmdTimeoutHandler(5000);
	
}

void SetReCalib(void)
{
	FirstReCalib = TRUE;
}


static void AppTask_100msHandle(void)
{
	// add by jiangxl 2019-05-25 for LIN Test
	if(GetATETestCmd()==LIN_CMD_QFACTOR_REINIT)
	{
		if(FirstReCalib)
		{
			FirstReCalib = FALSE;
			ClrCalibFlag();
			//while(1);	//After clear calibration flag, execute dead loop for restart
		}
	}
	else
	{
		HAL_KickWatchDog();
	}
}

static void AppTask_1secHandler(void)
{
	//ͨ�ſ��ƽ�����ߵ�ƽ
		GPIO_SetOutput(GPIO_FSKTOGGLE, GPIO_SET);
	//Test_count1s++;
	//if(Test_count1s>10)
	//{
	//	FirstReCalib = TRUE;
	//	bReQfInit = TRUE;
	//	Test_count1s = 0;
	//}
	
}

static void AppTask_1minHandler(void)
{
	
}

void App_SetErr(APP_ERROR_TYPE err)
{
	if(err & APP_ERROR_CLEAR)
	{
		gApp_error &= ~err;
	}
	else
	{
		gApp_error |= err;
	}
}

APP_ERROR_TYPE App_GetErr(void)
{
    return gApp_error;
}

void AppTask_Poll(void)
{
    static TIMER_DATA TimerData;
    static uint16 wAppLastTimerTicks;
    
	uint16 wSecondsToAdd;
	uint16 wNumTicks;
	
	wNumTicks = ST_GetElapasedTime(wAppLastTimerTicks);
	wAppLastTimerTicks += wNumTicks;
	wAppLastTimerTicks &= 0xffffu;
	
	if (wNumTicks)
	{
		// 1 ms Tick
		if (1U <= wNumTicks)
		{			
			TimerData.w1msCount += wNumTicks;
			
			AppTask_1msHandle(wNumTicks);
			
			// 10 MS Tick
			if (NUM_1MS_COUNTS_FOR_10MS <= TimerData.w1msCount)
			{
				wNumTicks = TimerData.w1msCount;
				TimerData.w10msCount += (TimerData.w1msCount / NUM_1MS_COUNTS_FOR_10MS);
				TimerData.w1msCount %= NUM_1MS_COUNTS_FOR_10MS;
				
				AppTask_10msHandle(wNumTicks);
				
				// 100 MS Tick
				if (NUM_10MS_COUNTS_FOR_100MS <= TimerData.w10msCount)
				{
					TimerData.w100msCount += (TimerData.w10msCount / NUM_10MS_COUNTS_FOR_100MS);
					TimerData.w10msCount %= NUM_10MS_COUNTS_FOR_100MS;
					
					AppTask_100msHandle();
					
					// 1 SEC Tick
					if (NUM_100MS_COUNTS_FOR_1SEC <= TimerData.w100msCount)
					{
						wSecondsToAdd = (TimerData.w100msCount / NUM_100MS_COUNTS_FOR_1SEC);
						TimerData.w100msCount %= NUM_100MS_COUNTS_FOR_1SEC;
						TimerData.w1secCount += wSecondsToAdd;
						
						AppTask_1secHandler();
						
						if (NUM_1SEC_COUNTS_FOR_1MIN <= TimerData.w1secCount)
						{
							TimerData.w1minCount += (TimerData.w1secCount / NUM_1SEC_COUNTS_FOR_1MIN);
							TimerData.w1secCount %= NUM_1SEC_COUNTS_FOR_1MIN;
							
							AppTask_1minHandler();
						}
					}
				}
			}
		}
	}
}
