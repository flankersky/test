/*******************************************************************************
*
* Copyright 2012-2016 Freescale Semiconductor, Inc.
* Copyright 2017~2018 NXP.
* All rights reserved.
*******************************************************************************/
//----------------------
// APPLICATION INCLUDES
//----------------------
#include "defines.h"

#include "appCfg.h"
#include "wct_lib.h"
#include "event.h"

#include "hal.h"

#include "systemTimers.h"
//#include "systemDisplay.h"
#include "systemCommand.h"
#include "systemProtection.h"
#include "nvm.h"
//#include "systemCallback.h"

#include "wct_debug.h"
#include "systemTask.h"
#include "NVM.h"
#include "wct_LibParams.h"

#include "systemLINHandler.h"


// LIN Command handler 
// jiangxl 2019-03-14

static uint8 Last_ihu_command;
static uint8 Cur_ihu_command;
static uint16 ATEParams[16]={0};

static uint8 tempStatus;

void systemATEHandler(uint8 AteCmdType)
{
	uint8 byCoilId;
	
	QF_CALIB_PARAMS* pQfParams0;
	QF_CALIB_PARAMS* pQfParams1;
	QF_CALIB_PARAMS* pQfParams2;
	
	if(gWCT_Params.WCTInitFlag==FALSE)
	{
		WCT_Stop();
		ST_WaitMs(50);
		WCT_LibInit();
		gWCT_Params.WCTInitFlag = TRUE;
	}
	
	ATEParams[2] = 0;

	HAL_D_DCDC_SetVoltage(0, 6000);
	ST_WaitMs(150);//ST_WaitMs(20);  // modify by jiangxl 2019-12-12 after modify buckboost pid parameters
									// add time to wait Rail voltage steady
	ATEParams[2] = HAL_GetRailVoltage(0);
	
	ATEParams[4] = PROT_GetRRQDFittingInputCurrent(0,0,5000,127772);
	ATEParams[5] = PROT_GetRRQDFittingInputCurrent(0,1,5000,127772);
	ATEParams[6] = PROT_GetRRQDFittingInputCurrent(0,2,5000,127772);
	
	WCT_Stop();
	
	ATEParams[0] = HAL_GetBatteryVoltage();
	ATEParams[1] = HAL_GetInputCurrent(0);

	ATEParams[3] = HAL_GetTopTemperature(0);
	
	
	ATEParams[10] = gWCT_Params.Qfactor_coil0;
	ATEParams[11] = gWCT_Params.Qfactor_coil1;
	ATEParams[12] = gWCT_Params.Qfactor_coil2;

	// When ATE test, not measure Q factor to short test time
	if(AteCmdType==ATE_CMD_PART)
	{
		ATEParams[7] = 0;
		ATEParams[8] = 0;
		ATEParams[9] = 0;
	}
	else
	{
		pQfParams0 = NVM_GetQfCalibParams(0, 0);
		pQfParams1 = NVM_GetQfCalibParams(0, 1);
		pQfParams2 = NVM_GetQfCalibParams(0, 2);

	/*
	 *  Call QFactor Initial for calculation
	 * 
	 * 
	 */
		WBG_InitParams(); //QֵУ��

		ATEParams[7]=pQfParams0->dwInitQlc;
		ATEParams[8]=pQfParams1->dwInitQlc;
		ATEParams[9]=pQfParams2->dwInitQlc;
	}
	
	//ST_WaitMs(1000);
	
	if(gWCT_Params.WCTInitFlag==TRUE)
	{
		//WCT_Stop();
		ST_WaitMs(50);
		WCT_LibInit();
		ST_WaitMs(50);	//after call WCT_LibInit(), must Call ST_WaitMs(50)!!!!! jiangxl 2019-12-14
		gWCT_Params.WCTInitFlag = FALSE;
	}
	
}


uint16 GetAteParams0()
{
	return ATEParams[0];
}

uint16 GetAteParams1()
{
	return ATEParams[1];
}

uint16 GetAteParams2()
{
	return ATEParams[2];
}

uint16 GetAteParams3()
{
	return ATEParams[3];
}

uint16 GetAteParams4()
{
	return ATEParams[4];
}

uint16 GetAteParams5()
{
	return ATEParams[5];
}

uint16 GetAteParams6()
{
	return ATEParams[6];
}

uint16 GetAteParams7()
{
	return ATEParams[7];
}

uint16 GetAteParams8()
{
	return ATEParams[8];
}

uint16 GetAteParams9()
{
	return ATEParams[9];
}

uint16 GetAteParams10()
{
	return ATEParams[10];
}

uint16 GetAteParams11()
{
	return ATEParams[11];
}

uint16 GetAteParams12()
{
	return ATEParams[12];
}



