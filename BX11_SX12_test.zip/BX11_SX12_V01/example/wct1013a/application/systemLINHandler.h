/*******************************************************************************
*
* Copyright 2012-2015 Freescale Semiconductor, Inc.
* Copyright 2017~2018 NXP.
* All rights reserved.
*******************************************************************************/

#ifndef __SYSTEMLINHANDLER_H__
#define __SYSTEMLINHANDLER_H__


void LINCommandOut_Handler(uint16 wNumTicks);
void LINCommandIn_Handler(uint16 wNumTicks);
void LINCommand_Init(void);

void systemATEHandler(uint8 AteCmdType);

void PEPS_Handler(void);

uint16 GetAteParams0(void);
uint16 GetAteParams1(void);
uint16 GetAteParams2(void);
uint16 GetAteParams3(void);
uint16 GetAteParams4(void);
uint16 GetAteParams5(void);
uint16 GetAteParams6(void);
uint16 GetAteParams7(void);
uint16 GetAteParams8(void);
uint16 GetAteParams9(void);
uint16 GetAteParams10(void);
uint16 GetAteParams11(void);
uint16 GetAteParams12(void);

#endif
