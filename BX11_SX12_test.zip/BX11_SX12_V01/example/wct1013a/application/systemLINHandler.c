/*******************************************************************************
*
* Copyright 2012-2016 Freescale Semiconductor, Inc.
* Copyright 2017~2018 NXP.
* All rights reserved.
*******************************************************************************/
//----------------------
// APPLICATION INCLUDES
//----------------------
#include "defines.h"

#include "appCfg.h"
#include "wct_lib.h"
#include "event.h"
#include "MWCT1013A.h"
#include "gpio.h"
//#include "hal.h"

#include "systemTimers.h"
//#include "systemDisplay.h"
#include "systemCommand.h"
//#include "systemProtection.h"
//#include "systemCallback.h"

//#include "wct_debug.h"
#include "systemTask.h"
#include "NVM.h"
#include "wct_LibParams.h"

#include "systemLINHandler.h"


// LIN Command handler 
// jiangxl 2019-03-14

static uint8 Last_ihu_command;
static uint8 Cur_ihu_command;

static uint8 tempStatus;
static uint8 ATETestEn;

 uint8 WpcStatus;

static uint8 PEPS_Stop_B=0;
static uint8 PEPS_NUM_UP=0;

void LINCommand_Init(void)
{
	Last_ihu_command = 0x03;
	Cur_ihu_command = 0x03;
}


/***********************************************************************/
//���POIG A1 ���� �� �ߵ�ƽ������̬Ϊ 0  �͵�ƽΪ 1
//�͵�ƽʹ�ܹ����߳�
/***********************************************************************/

void PEPS_Handler(void)
{
  if(gWCT_Params.WPCMuteSt==1)
  {
	if((GPIOA_DR&0x02)>0)
	{
		if(PEPS_NUM_UP<100)
		    PEPS_NUM_UP++;
	}
	else
	{
		PEPS_NUM_UP=0;
	}
	
	
	if(PEPS_NUM_UP>1)
	{
	   if(WpcStatus==3||WpcStatus==4||WpcStatus==0)
	   {
		   
	   }
	   else
	   {
		WCT_Stop();
		PEPS_Stop_B=1;
		ST_WaitMs(50);
		WCT_Stop();
		PEPS_Stop_B=1;
		
	   }
	}
	else
	{
	   if(PEPS_Stop_B==1)
	   {
		   ST_WaitMs(100);
		   WCT_LibInit();				
		   ST_WaitMs(100); //ÿ�γ�ʼ������Ҫ��ʱ50ms 
	   }
	   PEPS_Stop_B=0;
	}

  }	
	
}
/************************************************************************/
// LIN Command in -- ihu_command
//  Bit7~Bit2:	Reserved
//  Bit1: NFC active/inactive
//             1: active NFC function
//             0: don't active NFC function
//  Bit0: WPC work/not work
//             1: command WPC to work
//             0: don't command WPC to work
//
/************************************************************************/
void LINCommandIn_Handler(uint16 wNumTicks)
{
	uint8 WpcEna;
	Cur_ihu_command = gWCT_Params.LinCmd;//GetLINCommandIn();		// call LIN driver Command in
	if(Cur_ihu_command != Last_ihu_command)
	{
		//NVM_StoreStParams(&Cur_ihu_command);		// if current command differs from last command, store into NVM first!
		WpcEna = Cur_ihu_command&0x01;
		if(WpcEna==1)				// bit0==0 Don't command WPC to work
		{
			gWCT_Params.WPCMuteSt = 0x0;
			//CMD_Notify(WCT_CMD_STOP_LIB);			// stop WCT
			if(gWCT_Params.WCTInitFlag==FALSE)
			{
				WCT_Stop();
				gWCT_Params.WCTInitFlag = TRUE;
			}
		}
		else 										// bit==1 command WPC to work
		{
			gWCT_Params.WPCMuteSt = 0x1;
			//CMD_Notify(WCT_CMD_START_LIB);			// start WCT
			if(gWCT_Params.WCTInitFlag==TRUE)
			{
				WCT_LibInit();
				
				ST_WaitMs(50); //ÿ�γ�ʼ������Ҫ��ʱ50ms
				gWCT_Params.WCTInitFlag = FALSE;
			}
		}
		Last_ihu_command = Cur_ihu_command;			// update Last_ihu_command
	}
}

/************************************************************************/
// LIN Command out -- Status
//  Bit7:	Reserved
//	Bit6:	Card storage is/not working properly  
//             1: Card storage is working properly  
//             0: Card storage is not working properly
//  Bit2~Bit5: wpc_status
//             0: no device to charged
//             1: the device is charging
//             2: miss aligned
//             3: the device is over heat/FOD
//             4: the device is fully charged
//             5: SW error
//             6: HW error
//  Bit1: NFC active/inactive
//             1: NFC is active
//             0: NFC is not active
//  Bit0: WPC work/not work
//             1: WPC is working
//             0: WPC is not working
//
/************************************************************************/
//���CX11
/*void LINCommandOut_Handler(uint16 wNumTicks)
{
	uint8 WpcStatus;
	uint8 status;
	
	
    TX_CHARGING_STATUS TxStatus = WCT_GetTxStatus(0);
    TX_CHARGING_ERRORS TxErrors = WCT_GetTxError(0);
    RX_CHARGING_STATUS RxStatus = WCT_GetRxStatus(0);
    RX_CHARGING_ERRORS RxErrors = WCT_GetRxError(0);
    
    status = 0x0;
    tempStatus = gWCT_Params.WPCMuteSt;
    
    if((TxErrors==TX_FOD_ERROR)||(TxErrors==TX_QFOD_ERROR)||(TxErrors==TX_PRE_FOD_ERROR))
    {
    	status = 0x3;
    	tempStatus = 0x0;
    }
    else if(TX_CHIP_ERROR == TxErrors)
    {
    	status = 0x6;
    	tempStatus = 0x0;
    }
    else if(RX_NONE == RxStatus)
    {
    	status = 0x0;
    }
    else if(RX_CHARGING == RxStatus)
    {
    	status = 0x1;
    }
    else if(RX_CHARGED == RxStatus)
    {
    	status = 0x4;
    }
    else 
    {
    	status = 0x0;
    }

	WpcStatus = (tempStatus&0x01) | (0<<1) | ((status&0x0f)<<2) | (0<<6);
	SetLINCommandOut(WpcStatus);
}

*/

//SX12 BX11���ݽ���
uint8 WpcStatus_DELAY=0;
uint16 VOL_DELAY_4S=0;

void LINCommandOut_Handler(uint16 wNumTicks)
{
	//uint8 WpcStatus;
	uint8 status;
	
	
    TX_CHARGING_STATUS TxStatus = WCT_GetTxStatus(0);
    TX_CHARGING_ERRORS TxErrors = WCT_GetTxError(0);
    RX_CHARGING_STATUS RxStatus = WCT_GetRxStatus(0);
    RX_CHARGING_ERRORS RxErrors = WCT_GetRxError(0);
    // APP_NVM_ERROR       = 0x01,  APP_OVER_TEMP_ERROR = 0x02, APP_OVER_VOL_ERROR  = 0x04,  APP_UNDER_VOL_ERROR = 0x08,
    APP_ERROR_TYPE App_err_status = App_GetErr();       
    
	   //WpcStatus = 0x1;
    tempStatus = gWCT_Params.WPCMuteSt; // gWCT_Params.WPCMuteSt Ϊ���߳�Ŀ���״̬       //��Ҫ�ɼ����� ����ѹ  
    
    if(tempStatus==1)
    {	
     if(App_err_status==APP_OVER_TEMP_ERROR)
    	   {
    	     WpcStatus = 0x0; 
    	   }
    // else if((TxErrors==TX_FOD_ERROR)||(TxErrors==TX_QFOD_ERROR)||(TxErrors==TX_PRE_FOD_ERROR)) //fod
     else if((TxErrors==TX_FOD_ERROR)||(TxErrors==TX_QFOD_ERROR)) 
           {
    	     WpcStatus = 0x3;
           }
      else if(PEPS_Stop_B == 1)
           {
          	WpcStatus = 0x6;
           }
      else if(App_err_status==APP_OVER_VOL_ERROR||App_err_status==APP_UNDER_VOL_ERROR)
           {
    	     //��Ҫ��ʱ4�뱨�͵�ѹ
    	     if(VOL_DELAY_4S>400)
    	        {
    	    	 WpcStatus = 0x4; 
    	        }
    	     else
    	     {
    	    	 VOL_DELAY_4S++; 
    	     }
    	     
           }
      else if(TX_CHIP_ERROR == TxErrors||App_err_status==APP_NVM_ERROR) //������
            {
    	     //WpcStatus = 0x7;
            }
      else if(RX_NONE == RxStatus)  //����״̬
            {
    	/////////////////////////////////////////////////////  
    	     if(WpcStatus_DELAY<=2)
    	     {
    	      WpcStatus = 0x1;
    	     }
    	     else
    	     {
    	    	 WpcStatus_DELAY--;
    	     }
    	////////////////////////////////////////////////////     
            }
      else if(RX_CHARGING == RxStatus) //���ڳ��
           {
    	     WpcStatus = 0x2;              //�ӳ����絽������Ҫ2.2S����ʱ����ʱ��
    	     
    	     WpcStatus_DELAY=110;
    	     
           }
      else if(RX_CHARGED == RxStatus) //������
           {

    	       /////////////////////////////////////////////////////  
    	      	     if(WpcStatus_DELAY<=2)
    	      	     {
    	      	      WpcStatus = 0x1;
    	      	     }
    	      	     else
    	      	     {
    	      	    	 WpcStatus_DELAY--;
    	      	     }
    	      	//////////////////////////////////////////////////// 
    	    
           }
      else
           {
    	    //WpcStatus = 0x1;
    	  /////////////////////////////////////////////////////  
    	      	      	     if(WpcStatus_DELAY<=2)
    	      	      	     {
    	      	      	      WpcStatus = 0x1;
    	      	      	     }
    	      	      	     else
    	      	      	     {
    	      	      	    	 WpcStatus_DELAY--;
    	      	      	     }
    	      	      	//////////////////////////////////////////////////// 
           }
    }
    else
    {
    	WpcStatus = 0x7;
    }
	//WpcStatus = (tempStatus&0x01) | (0<<1) | ((status&0x0f)<<2) | (0<<6);
	SetLINCommandOut(WpcStatus);
}
