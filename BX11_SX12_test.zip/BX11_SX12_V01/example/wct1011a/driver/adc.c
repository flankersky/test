/*******************************************************************************
 * This software is provided AS IS and without warranty of any kind. 
 * Your right to use this software is subject to separate terms and conditions entered between you and NXP.
 * If you have not entered into such terms, you have no license rights to use the code.
 * Copyright 2012-2016 Freescale Semiconductor, Inc.
 * Copyright 2017~2019 NXP.
 * All rights reserved.
*******************************************************************************/

#include "defines.h"
#include "cpu.h"

#include "systemDebug.h"

#include "adc.h"

void ADC_Init( void )
{	
	ADC_CTRL1   = 0x0805U;	//ADCA interrupt enable; triggered parallel mode
	ADC_CTRL2   = 0x9004U;	//ADCB allows external sync trigger; ADCA clock = coreClock/5	
	ADC_PWR2    = 0x0400U;	//ADCB clock = coreClock/5	
	ADC_CLIST1  = 0x0675U;
	ADC_CLIST2  = 0x1243U;
	ADC_CLIST3  = 0xDA98U;
	ADC_CLIST4  = 0xECBFU;
	ADC_SDIS    = 0xE0E0U;

	ADC_STAT    = 0x1800u;   // clear interrupt flags by writting a 1 to them
	ADC_CTRL1  |= 0x0800u;   // Enable ADCA end of scan interrupts
	
	ADC_PWR = 0x01A0U;	//power the ADC module
	
	// Wait for power-up to complete
	while (( ADC_PWR & ( BIT10 | BIT11) )!= 0u)
	{ }
}


void ADC_GetResult(uint8 byId, uint16 *pwData, uint8 byLen)
{
	uint16 *pAdcResultReg;
	if(ADC_MISC_INDEX == byId)
	{
		pAdcResultReg = (uint16*)&ADC_RSLT0;
	}
	else if(ADC_DMA_INDEX == byId)
	{
		pAdcResultReg = (uint16*)&ADC_RSLT8;
	}
	else
	{
		DBG_Assert(1, 0, byId);
	}
	
	if(pwData)
	{
		while(byLen--)
		{
			uint16 adcData = *pAdcResultReg++;
			*pwData++ = (adcData>>3);
		}
	}
}

uint8 ADC_CheckConvertionFinished(uint8 byId)
{
    uint8 ret = 0;
    if(ADC_DMA_INDEX == byId)
    {        
        if(ADC_STAT & BIT12)
        {
            ret = 1;
        }
    }
    else if(ADC_MISC_INDEX == byId)
    {
    	if(ADC_STAT & BIT11)
		{
			ret = 1;
		}
    }
	return ret;
}

uint8 ADC_CheckConvertionOngoing(uint8 byId)
{
    uint8 ret = 0;
    if(ADC_DMA_INDEX == byId)
    {        
        if(ADC_STAT & BIT14)
        {
            ret = 1;
        }
    }
    else if(ADC_MISC_INDEX == byId)
    {
    	if(ADC_STAT & BIT15)
		{
			ret = 1;
		}
    }
	return ret;
}

void ADC_ClearConvertionFinishedFlag(uint8 byId)
{
    if(ADC_DMA_INDEX == byId)
    {
    	ADC_STAT = BIT12;
    }
    else if(ADC_MISC_INDEX == byId)
    {
    	ADC_STAT = BIT11;
    }
}

void ADC_SetChannelIndex(uint8 byId, uint8 byChIndex)
{
	if(ADC_DMA_INDEX == byId)
	{
		ADC_CLIST3 &= ~0x000F;
		if(ADC_DMA_CHANNEL_DDM_INDEX == byChIndex)
		{	
			ADC_CLIST3 |= 0x08;
		}
		else if(ADC_DMA_CHANNEL_QVOLT_INDEX == byChIndex)
		{
			ADC_CLIST3 |= 0x0B;
		}
		else
		{
			DBG_Assert(1, 0, byChIndex);
		}
	}
	else
	{
		DBG_Assert(1, 0, byId);
	}
}

void ADC_ISRAck(uint8 byId)
{
	if(ADC_MISC_INDEX == byId)
	{
		ADC_ClearConvertionFinishedFlag(byId);
	}
}

//Manual start ADC to sample
void ADC_StartConversion(uint8 byId)
{
	if(ADC_DMA_INDEX == byId)
	{        
		ADC_CTRL2 |= BIT13;
	}
	else if(byId == ADC_MISC_INDEX)
	{
		ADC_CTRL1 |= BIT13;
	}
}

//Return result register byte address
uint32 ADC_GetResultRegAddr(uint8 byId)
{
	uint32 addr = 0;
	if(ADC_DMA_INDEX == byId)
	{
		addr = (uint32)&ADC_RSLT8;
		addr *= 2;
	}
	else
	{
		DBG_Assert(1, 0, byId);
	}
	return addr;
}

void ADC_PowerDown(void)
{
	ADC_PWR |= (ADC_PWR_PD1 | ADC_PWR_PD0);
}

void ADC_PowerUp(void)
{
	ADC_PWR &= ~(ADC_PWR_PD1 | ADC_PWR_PD0);
	// Wait for power-up to complete
	while (( ADC_PWR & ( BIT10 | BIT11)) != 0u) {}
}
