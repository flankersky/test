/*******************************************************************************
 * This software is provided AS IS and without warranty of any kind. 
 * Your right to use this software is subject to separate terms and conditions entered between you and NXP.
 * If you have not entered into such terms, you have no license rights to use the code.
 * Copyright 2012-2016 Freescale Semiconductor, Inc.
 * Copyright 2017~2019 NXP.
 * All rights reserved.
*******************************************************************************/

#include "defines.h"
#include "cpu.h"
#include "appcfg.h"

#include "systemDebug.h"

#include "sim.h"

void SIM_Init(void)
{
	if (!(SIM_MISC0 & SIM_MISC0_MODE_STAT))  // in normal mode, switch to fast mode
	{
		SIM_MISC0 |= SIM_MISC0_FAST_MODE;
		SIM_CTRL |= SIM_CTRL_SWRst;
	}
	
	SIM_CLKOUT = 0x1020U;	//Disable clock output
	SIM_GPSCH  = 0x0000U;
#if DIGITAL_DCDC
	SIM_GPSFL  = 0x0504U;	//GPIOF4/F5 = XB_OUT8/XB_OUT9
#else
	SIM_GPSFL  = 0x0004U;	//GPIOF4/F5 = TXD1/RXD1
#endif	
	SIM_PCE0   = 0xF07EU;
	SIM_PCE1   = 0x3A01U;
	SIM_PCE2   = 0x1E8CU;
	SIM_PCE3   = 0x00F0U;
	SIM_PCR    = 0x0C00U;
	SIM_SD2    = 0x0004U;	//PIT1 works in STOP mode
	SIM_IPSn   = 0x0100U;	//TA0 from XB_OUT34
}
