/*******************************************************************************
 * This software is provided AS IS and without warranty of any kind. 
 * Your right to use this software is subject to separate terms and conditions entered between you and NXP.
 * If you have not entered into such terms, you have no license rights to use the code.
 * Copyright 2012-2016 Freescale Semiconductor, Inc.
 * Copyright 2017~2019 NXP.
 * All rights reserved.
*******************************************************************************/

#ifndef __APP_CFG_H__
#define __APP_CFG_H__

//---------------------------- Application Version Defines -----------------------------
#define WCT_SW_VERSION                     0x4100u //x.y.z: 4 bit x, 4 bit y, 8 bit z
#define WCT_HW_VERSION                     0x1000u //x.y.z: 4 bit x, 4 bit y, 8 bit z

#define DEVICE_ID_STRING                   "MPTX-MPA9-WCT1011A"
#define NUM_DEVICES                        1u
#define NUM_COILS_PER_DEVICE               3u

#define NVM_BASE_ADDR                      ( 0x7600UL << 1 )

#define FREEMASTER_SUPPORTED	           (TRUE)
#define DEBUG_CONSOLE_SUPPORTED            (FALSE)
#define LOW_POWER_MODE_ENABLE			   (FALSE)

#define DIGITAL_DCDC					   (TRUE)

#define BOOTLOADER_USED					   (FALSE)
#define BOOTLOADER_PARAMS_ADDR			   ( 0x000077FCUL << 1 )

#endif
